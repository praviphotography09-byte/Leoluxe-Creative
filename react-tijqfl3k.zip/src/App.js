import React, { useState, useEffect, useRef } from 'react';
import {
  motion,
  AnimatePresence,
  useScroll,
  useTransform,
} from 'framer-motion';

export default function App() {
  const [activeTab, setActiveTab] = useState('wedding');
  const [activeImage, setActiveImage] = useState(null);
  const [musicOn, setMusicOn] = useState(false);
  const canvasRef = useRef(null);
  const audioRef = useRef(null);

  // 🌊 SCROLL ENGINE (GOD LEVEL)
  const { scrollYProgress } = useScroll();
  const heroScale = useTransform(scrollYProgress, [0, 0.3], [1, 1.3]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.25], [1, 0]);
  const heroY = useTransform(scrollYProgress, [0, 0.3], [0, 120]);

  const heroVideo =
    'https://cdn.coverr.co/videos/coverr-wedding-photography-8280/1080p.mp4';
  const instagramHandle = 'leoluxe_photography';

  const gallery = {
    wedding: [
      'https://images.unsplash.com/photo-1529634806980-85c3dd6d8e6f',
      'https://images.unsplash.com/photo-1523438097201-512ae7d59c8a',
    ],
    portrait: [
      'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee',
      'https://images.unsplash.com/photo-1544005313-94ddf0286df2',
    ],
    product: [
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9',
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30',
    ],
  };

  const toggleMusic = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (musicOn) audio.pause();
    else audio.play();
    setMusicOn(!musicOn);
  };

  // ✨ PARTICLE BACKGROUND
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let particles = [];

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resize();
    window.addEventListener('resize', resize);

    for (let i = 0; i < 80; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 2,
        dx: (Math.random() - 0.5) * 0.5,
        dy: (Math.random() - 0.5) * 0.5,
      });
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      particles.forEach((p) => {
        p.x += p.dx;
        p.y += p.dy;

        if (p.x < 0 || p.x > canvas.width) p.dx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.dy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255,215,0,0.6)';
        ctx.fill();
      });

      requestAnimationFrame(animate);
    };

    animate();
  }, []);

  return (
    <div
      style={{
        background: '#000',
        color: '#fff',
        overflowX: 'hidden',
        fontFamily: 'Arial',
      }}
    >
      {/* 🎇 PARTICLES */}
      <canvas
        ref={canvasRef}
        style={{ position: 'fixed', top: 0, left: 0, zIndex: 0 }}
      />

      {/* 🎵 AUDIO */}
      <audio ref={audioRef} loop>
        <source src="https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8a3f6a6.mp3" />
      </audio>

      {/* 🔮 FLOATING GLASS NAV */}
      <motion.div
        style={{
          position: 'fixed',
          top: 20,
          left: '50%',
          transform: 'translateX(-50%)',
          zIndex: 9999,
          display: 'flex',
          gap: 10,
          padding: '10px 18px',
          borderRadius: 50,
          background: 'rgba(255,255,255,0.05)',
          backdropFilter: 'blur(20px)',
        }}
      >
        {Object.keys(gallery).map((tab) => (
          <motion.button
            key={tab}
            whileHover={{ scale: 1.1 }}
            onClick={() => setActiveTab(tab)}
            style={{
              padding: '8px 14px',
              borderRadius: 30,
              border: '1px solid #333',
              background: activeTab === tab ? 'gold' : 'transparent',
              color: activeTab === tab ? '#000' : '#fff',
              cursor: 'pointer',
            }}
          >
            {tab.toUpperCase()}
          </motion.button>
        ))}

        <button
          onClick={toggleMusic}
          style={{
            padding: '6px 10px',
            borderRadius: 20,
            background: 'gold',
            border: 'none',
          }}
        >
          {musicOn ? '🔊' : '🔇'}
        </button>
      </motion.div>

      {/* 🚀 HERO */}
      <motion.section
        style={{
          height: '100vh',
          scale: heroScale,
          opacity: heroOpacity,
          y: heroY,
          position: 'relative',
        }}
      >
        <video
          autoPlay
          loop
          muted
          playsInline
          style={{ width: '100%', height: '100%', objectFit: 'cover' }}
        >
          <source src={heroVideo} />
        </video>

        <div
          style={{
            position: 'absolute',
            inset: 0,
            background: 'radial-gradient(circle, rgba(0,0,0,0.3), #000)',
          }}
        />

        <motion.div
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2 }}
          style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%,-50%)',
            textAlign: 'center',
          }}
        >
          <h1 style={{ fontSize: 80, letterSpacing: 2 }}>Leoluxe Studio</h1>
          <p style={{ opacity: 0.7 }}>
            Cinematic • Luxury • Immersive Experience
          </p>
        </motion.div>
      </motion.section>

      {/* 🧠 ABOUT */}
      <motion.section
        initial={{ opacity: 0, y: 80 }}
        whileInView={{ opacity: 1, y: 0 }}
        style={{ padding: 140, textAlign: 'center' }}
      >
        <h2 style={{ fontSize: 44 }}>
          We Don’t Capture Photos — We Create Emotion
        </h2>
        <p style={{ maxWidth: 800, margin: 'auto', opacity: 0.6 }}>
          Ultra-premium cinematic photography powered by storytelling, light,
          and luxury aesthetics.
        </p>
      </motion.section>

      {/* 🎬 GALLERY */}
      <section style={{ padding: 80, background: '#111' }}>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit,minmax(260px,1fr))',
            gap: 20,
          }}
        >
          {gallery[activeTab].map((img, i) => (
            <motion.div
              key={i}
              whileHover={{ scale: 1.08, rotateY: 12, rotateX: 8 }}
              style={{ transformStyle: 'preserve-3d', cursor: 'pointer' }}
              onClick={() => setActiveImage(img)}
            >
              <img
                src={img}
                style={{
                  width: '100%',
                  height: 260,
                  objectFit: 'cover',
                  borderRadius: 18,
                }}
              />
            </motion.div>
          ))}
        </div>
      </section>

      {/* 🔍 LIGHTBOX */}
      {activeImage && (
        <motion.div
          onClick={() => setActiveImage(null)}
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.95)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <img
            src={activeImage}
            style={{ maxWidth: '92%', maxHeight: '92%' }}
          />
        </motion.div>
      )}

      {/* 💎 FOOTER */}
      <footer style={{ padding: 80, textAlign: 'center', opacity: 0.6 }}>
        <h2>Leoluxe Studio</h2>
        <p>Luxury Cinematic Experience</p>
        <p style={{ color: 'gold' }}>Instagram @{instagramHandle}</p>
      </footer>
    </div>
  );
}
